#!/bin/bash
xte 'key Escape'
xte 'usleep 100000'
xte 'key Return'
xte 'usleep 100000'

